package takuseki2001.gmail.com.kadai2;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
//カラーピッカーのクラスと、描画画面についてのの宣言
    private MyView mv;
    int selectColor;
    private ColorPickerDialog cpd;
    private ColorPickerView cpv;
    private int width_count=1; //ペンの太さを制御するカウント

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mv = (MyView)findViewById(R.id.myView);

        //インスタンス化　ボタンで呼び出す
        cpd = new ColorPickerDialog(this,new ColorPickerDialog.OnColorChangedListener() {
            public void colorChanged(int color) {
                selectColor = color;
            } }
                , Color.BLACK);
    }

    //諸々のボタン処理　xmlでクリック時について動作を登録
    public void onClear(View v){
        mv.Clear_Canvas();
    }
    public void Color_Change(View v) {
        cpd.show();
    }
    public void undo(View v){ mv.undo(); }
    public void redo(View v){ mv.redo();}
    //色を選んでそれをpaintに反映する
    public void onApply(View v){
        cpv = new ColorPickerView(this, new ColorPickerDialog.OnColorChangedListener() {
            public void colorChanged(int color) { selectColor=color; }
        },cpd.iro);
        mv.paint.setColor(cpd.iro);
    }

    public void setWidth(View v){
        if(width_count==0){
            mv.paint.setStrokeWidth(5);
            width_count++;
        }
        else if(width_count==1){
            mv.paint.setStrokeWidth(10);
            width_count++;
        }
        else{
            mv.paint.setStrokeWidth(15);
            width_count=0;
        }
    }

    //確認用トースト
    /*public void Toast(String message){
        Toast toast = Toast.makeText(this,message,Toast.LENGTH_SHORT);
        toast.show();
    }*/
}