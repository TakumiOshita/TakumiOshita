package takuseki2001.gmail.com.kadai2;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class MyView extends View {

    private List<DrawLine> lines;
    private final List<DrawLine> past; //これを参考にしてredoする
    private Path path; //細かく線を引く
    public Paint paint;  //鉛筆のようなもの


    public MyView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        //ペンとパスをインスタンス化
        path = new Path();
        paint = new Paint();

        paint.setColor(Color.BLACK); //初期カラー
        paint.setStrokeWidth(5); //ペンの太さ
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);
        paint.setStrokeWidth(5);
        //それぞれリストをインスタンス化
        lines = new ArrayList<DrawLine>();
        past = new ArrayList<DrawLine>();
    }

    //過去のデータについて扱うクラス
    class DrawLine {
        private Paint past_paint;
        private Path past_path;

        DrawLine(Path path, Paint paint) {
            past_paint = new Paint(paint);
            past_path = new Path(path);
        }
        void draw(Canvas canvas) {
            canvas.drawPath(past_path, past_paint);
        }
    }

    //undo機能  これらのundo,redoは単純すぎてlinesやpastがnullのところにアクセスするとアプリ落ちる。if分岐で処理
    public void undo(){
        if(lines.size()>0){
            lines.remove(lines.size() - 1); //最後の要素を削除
            invalidate();
        }
        else{}
    }
    //redo機能
    public void redo(){
        if(lines.size()<past.size()){
            lines.add(past.get(lines.size()));
            invalidate();
        }
        else{
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //画面クリアで履歴を削除した場合にのみ、redoの機能もリセットする必要がある
                if(lines==null) past.clear();
                path.moveTo(x, y);
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(x, y);
                break;
            case MotionEvent.ACTION_UP:
                path.lineTo(x, y);
                // 指を離したので、履歴に追加する
                lines.add(new DrawLine(this.path, this.paint));
                past.add(new DrawLine(this.path, this.paint));
                // パスをリセットする
                // これを忘れると、全ての線の色が変わってしまう
                //リセットしないと今までの全てのパス全てがonDrawに入ってしまうため
                path.reset();
                break;
        }
        invalidate();
        return true;
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // キャンバスをクリア
        canvas.drawColor(Color.WHITE);
        // 履歴から線を描画
        for(DrawLine line : lines) {
            line.draw(canvas);
        }
        // 現在、描いている線を描画
        canvas.drawPath(path, paint);
    }

    //クリア処理
    public void Clear_Canvas(){
        // 履歴をクリア
        lines.clear();
        past.clear();
        // 現在の線をクリア
        path.reset();
        invalidate();
    }
}


