//参考サイト　http://y-anz-m.blogspot.com/2010/05/androidcolorpickerdialog.html

package takuseki2001.gmail.com.kadai2;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;

public class ColorPickerDialog extends Dialog {

    public interface OnColorChangedListener {
        void colorChanged(int color);
    }

    private OnColorChangedListener mListener;
    private int mInitialColor;
    public int iro; //mainactivityで触るためにpublicの変数を追加しておく

    public ColorPickerDialog(Context context, OnColorChangedListener listener, int initialColor) {
        super(context);
        //初期変数の設定　mainactivityからもらってくる
        mListener = listener;
        mInitialColor = initialColor;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        OnColorChangedListener l = new OnColorChangedListener() {
            public void colorChanged(int color) { //ダイアログのタッチによってボタンの色を変えるごとにpaint用の色も取得
                mListener.colorChanged(color);
                iro = color;
                dismiss();
            }
        };

        LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
        setContentView(new ColorPickerView(getContext(), l, mInitialColor), lp);
        setTitle("- Color -");
    }

}